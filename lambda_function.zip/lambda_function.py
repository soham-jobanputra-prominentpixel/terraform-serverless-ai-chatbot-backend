import json
import os
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Dict, Any, List

import boto3
from boto3.dynamodb.conditions import Key


# =========================================================
# AWS Clients
# =========================================================

dynamodb = boto3.resource("dynamodb")
bedrock = boto3.client("bedrock-runtime")

TABLE_NAME = os.environ["DYNAMODB_TABLE"]
MODEL_ID = os.environ["MODEL_ID"]

table = dynamodb.Table(TABLE_NAME)

print(f"[INIT] TABLE_NAME={TABLE_NAME} MODEL_ID={MODEL_ID}")


# =========================================================
# Helpers
# =========================================================

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Methods": "*",
        },
        "body": json.dumps(body, default=decimal_serializer),
    }


def decimal_serializer(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError


def parse_body(event: Dict[str, Any]) -> Dict[str, Any]:
    body = event.get("body")

    if not body:
        return {}

    if isinstance(body, str):
        return json.loads(body)

    return body


def extract_title(message: str) -> str:
    cleaned = message.strip().replace("\n", " ")

    if len(cleaned) <= 40:
        return cleaned

    return cleaned[:37] + "..."


def get_session_metadata(session_id: str):
    print(f"[DYNAMO] get_session_metadata session_id={session_id}")

    result = table.get_item(
        Key={
            "sessionId": session_id,
            "dialogueTimestamp": "META"
        }
    )

    item = result.get("Item")
    print(f"[DYNAMO] get_session_metadata found={item is not None}")

    return item


def get_messages(session_id: str) -> List[Dict[str, Any]]:
    print(f"[DYNAMO] get_messages session_id={session_id}")

    result = table.query(
        KeyConditionExpression=(
            Key("sessionId").eq(session_id) &
            Key("dialogueTimestamp").begins_with("MSG#")
        ),
        ScanIndexForward=True
    )

    items = result.get("Items", [])
    print(f"[DYNAMO] get_messages count={len(items)}")

    return items


def save_message(session_id: str, role: str, text: str):
    timestamp = now_iso()
    sk = f"MSG#{timestamp}"

    print(f"[DYNAMO] save_message session_id={session_id} role={role} sk={sk} content_length={len(text)}")

    table.put_item(
        Item={
            "sessionId": session_id,
            "dialogueTimestamp": sk,
            "role": role,
            "content": text,
            "createdAt": timestamp,
            "type": "message",
        }
    )

    print(f"[DYNAMO] save_message OK")


def update_session_message_count(session_id: str, increment: int = 1):
    print(f"[DYNAMO] update_session_message_count session_id={session_id} increment={increment}")

    table.update_item(
        Key={
            "sessionId": session_id,
            "dialogueTimestamp": "META"
        },
        UpdateExpression="SET messageCount = if_not_exists(messageCount, :zero) + :inc",
        ExpressionAttributeValues={
            ":inc": increment,
            ":zero": 0
        }
    )

    print(f"[DYNAMO] update_session_message_count OK")


# =========================================================
# Route Handlers
# =========================================================

def create_session():
    session_id = str(uuid.uuid4())
    created_at = now_iso()

    print(f"[HANDLER] create_session session_id={session_id}")

    table.put_item(
        Item={
            "sessionId": session_id,
            "dialogueTimestamp": "META",
            "createdAt": created_at,
            "title": "New Chat",
            "messageCount": 0,
            "type": "metadata",
        }
    )

    print(f"[HANDLER] create_session OK session_id={session_id}")

    return response(201, {"sessionId": session_id, "createdAt": created_at})


def list_sessions():
    print(f"[HANDLER] list_sessions")

    result = table.scan(
        FilterExpression="#t = :meta",
        ExpressionAttributeNames={"#t": "type"},
        ExpressionAttributeValues={":meta": "metadata"}
    )

    sessions = result.get("Items", [])
    print(f"[HANDLER] list_sessions scanned_count={result.get('ScannedCount', 0)} matched={len(sessions)}")

    sessions.sort(key=lambda x: x.get("createdAt", ""), reverse=True)

    output = []
    for item in sessions:
        output.append({
            "id": item["sessionId"],
            "title": item.get("title", "New Chat"),
            "createdAt": item.get("createdAt"),
            "messageCount": item.get("messageCount", 0),
        })

    return response(200, output)


def delete_session(session_id: str):
    print(f"[HANDLER] delete_session session_id={session_id}")

    items = get_messages(session_id)
    metadata = get_session_metadata(session_id)

    if metadata:
        items.append(metadata)

    if not items:
        print(f"[HANDLER] delete_session not_found session_id={session_id}")
        return response(404, {"error": "Session not found"})

    print(f"[HANDLER] delete_session deleting items_count={len(items)}")

    with table.batch_writer() as batch:
        for item in items:
            batch.delete_item(
                Key={
                    "sessionId": item["sessionId"],
                    "dialogueTimestamp": item["dialogueTimestamp"]
                }
            )

    print(f"[HANDLER] delete_session OK session_id={session_id}")

    return response(200, {"message": "Session deleted", "sessionId": session_id})


def get_session_messages(session_id: str):
    print(f"[HANDLER] get_session_messages session_id={session_id}")

    metadata = get_session_metadata(session_id)

    if not metadata:
        print(f"[HANDLER] get_session_messages not_found session_id={session_id}")
        return response(404, {"error": "Session not found"})

    items = get_messages(session_id)

    messages = []
    for item in items:
        messages.append({
            "role": item["role"],
            "content": item["content"],
            "createdAt": item["createdAt"],
        })

    print(f"[HANDLER] get_session_messages OK session_id={session_id} count={len(messages)}")

    return response(200, {"sessionId": session_id, "messages": messages})


def send_message(session_id: str, body: Dict[str, Any]):
    user_message = body.get("message")

    print(f"[HANDLER] send_message session_id={session_id} message_length={len(user_message) if user_message else 0}")

    if not user_message:
        return response(400, {"error": "message is required"})

    metadata = get_session_metadata(session_id)

    if not metadata:
        print(f"[HANDLER] send_message not_found session_id={session_id}")
        return response(404, {"error": "Session not found"})

    history = get_messages(session_id)
    print(f"[HANDLER] send_message history_count={len(history)}")

    converse_messages = []
    for item in history:
        converse_messages.append({
            "role": item["role"],
            "content": [{"text": item["content"]}]
        })

    converse_messages.append({
        "role": "user",
        "content": [{"text": user_message}]
    })

    print(f"[BEDROCK] converse model_id={MODEL_ID} total_turns={len(converse_messages)}")

    bedrock_response = bedrock.converse(
        modelId=MODEL_ID,
        messages=converse_messages,
        inferenceConfig={
            "maxTokens": 512,
            "temperature": 0.7,
        }
    )

    usage = bedrock_response.get("usage", {})
    stop_reason = bedrock_response.get("stopReason")
    assistant_reply = bedrock_response["output"]["message"]["content"][0]["text"]

    print(f"[BEDROCK] converse OK stop_reason={stop_reason} input_tokens={usage.get('inputTokens')} output_tokens={usage.get('outputTokens')} reply_length={len(assistant_reply)}")

    save_message(session_id=session_id, role="user", text=user_message)
    save_message(session_id=session_id, role="assistant", text=assistant_reply)
    update_session_message_count(session_id, increment=2)

    if metadata.get("messageCount", 0) == 0:
        title = extract_title(user_message)
        print(f"[HANDLER] send_message updating title session_id={session_id} title={title!r}")

        table.update_item(
            Key={
                "sessionId": session_id,
                "dialogueTimestamp": "META"
            },
            UpdateExpression="SET title = :title",
            ExpressionAttributeValues={":title": title}
        )

    print(f"[HANDLER] send_message OK session_id={session_id}")

    return response(200, {"reply": assistant_reply, "sessionId": session_id})


# =========================================================
# Main Lambda Handler
# =========================================================

def lambda_handler(event, context):
    print(f"[REQUEST] event: {event}")
    
    # HTTP API v2 uses requestContext.http.method + rawPath
    # REST API / HTTP API v1 uses httpMethod + path
    http_method = (
        event.get("requestContext", {}).get("http", {}).get("method")
        or event.get("httpMethod", "")
    )
    path = event.get("rawPath") or event.get("path", "")

    print(f"[REQUEST] method={http_method} path={path} request_id={context.aws_request_id}")

    try:
        body = parse_body(event)
        path_parts = [p for p in path.split("/") if p]

        if http_method == "POST" and path == "/sessions":
            return create_session()

        if http_method == "GET" and path == "/sessions":
            return list_sessions()

        if http_method == "DELETE" and len(path_parts) == 2 and path_parts[0] == "sessions":
            return delete_session(path_parts[1])

        if http_method == "GET" and len(path_parts) == 3 and path_parts[0] == "sessions" and path_parts[2] == "messages":
            return get_session_messages(path_parts[1])

        if http_method == "POST" and len(path_parts) == 3 and path_parts[0] == "sessions" and path_parts[2] == "messages":
            return send_message(path_parts[1], body)

        if http_method == "OPTIONS":
            print(f"[REQUEST] CORS preflight")
            return response(200, {"ok": True})

        print(f"[REQUEST] route_not_found method={http_method} path={path}")
        return response(404, {"error": "Route not found"})

    except Exception as e:
        print(f"[ERROR] request_id={context.aws_request_id} method={http_method} path={path} error={type(e).__name__}: {e}")
        return response(500, {"error": "Internal server error", "details": str(e)})